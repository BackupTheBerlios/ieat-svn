Installing iEat

iEat pretty much runs directly out of the box and will run on ONLY a Windows based PC with java 1.5 or higher.
You must also have the TEMP variable set to a readable directory! But this is true on most windows systems.

To run just double click on run.bat